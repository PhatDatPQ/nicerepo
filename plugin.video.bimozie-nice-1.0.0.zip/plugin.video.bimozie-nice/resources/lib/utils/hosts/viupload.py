# -*- coding: utf-8 -*-

import re

from .. import xbmc_helper as helper
from .. import cpacker
from ..link_extractor import LinkExtractor
from ..mozie_request import Request
import xbmcgui

def get_link(url, media , link_parser):
    if re.search('viupload.com', url):
        helper.log("*********************** Apply viupload.com url %s" % url)
        req = Request()
        response = req.get(url, redirect=True, headers={
            'referer': media.get('originUrl')
        })
        listitems = []
        movie_items = []
        jsrp = LinkExtractor.play_sources_viupload(response)
        jsrp.reverse()
        # products = sorted(jsrp, key=lambda k: k['label'], reverse=True)
        for data in jsrp:
            movie_items.append((data['file'],data['label']))
            listitems.append("%s (%s)" % (data['label'], data['file']))
        selected_item = None
        if len(listitems) > 1:
            index = xbmcgui.Dialog().select("CHỌN LINK STREAM", listitems)
            if index == -1:
                return None, None
            else:
                selected_item = movie_items[index]

        media['link'] = selected_item[0]
        link_parser.set_media(media)
        return link_parser.get_link()
    else:
        helper.log("*********************** Apply viupload.net url %s" % url)
        req = Request()
        response = req.get(url, redirect=True, headers={
            'referer': media.get('originUrl')
        })

        content = cpacker.unpack(response)
        matches = re.findall('''['|"]?file['|"]?:['|"](.*?)['|"]''', content)
        if matches and len(matches) > 0:
            url = matches[0]

        return url, 'viupload'
